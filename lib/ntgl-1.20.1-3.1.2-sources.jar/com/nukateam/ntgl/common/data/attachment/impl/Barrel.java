package com.nukateam.ntgl.common.data.attachment.impl;

import com.nukateam.ntgl.common.util.interfaces.IWeaponModifier;

/**
 * An attachment class related to barrels. Barrels need to specify the length in order to render
 * the muzzle flash correctly. Use {@link #create(float, IWeaponModifier...)} to create an get.
 * <p>
 * Author: MrCrayfish
 */
public class Barrel extends Attachment {
    private final float length;

    public Barrel(float length, IWeaponModifier... modifier) {
        super(modifier);
        this.length = length;
    }

    /**
     * @return The length of the barrel in pixels
     */
    public float getLength() {
        return this.length;
    }

    /**
     * Creates a barrel get
     *
     * @param length    the length of the barrel model in pixels
     * @param modifiers an array of gun modifiers
     * @return a barrel get
     */
    public static Barrel create(float length, IWeaponModifier... modifiers) {
        return new Barrel(length, modifiers);
    }
}
