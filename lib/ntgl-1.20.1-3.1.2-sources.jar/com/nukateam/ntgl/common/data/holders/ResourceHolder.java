package com.nukateam.ntgl.common.data.holders;

import com.nukateam.ntgl.Ntgl;
import net.minecraft.resources.ResourceLocation;

public class ResourceHolder {
    protected final ResourceLocation id;

    public ResourceHolder(ResourceLocation id) {
        this.id = id;
    }

    public ResourceHolder(String name) {
        this.id = ResourceLocation.tryBuild(Ntgl.MOD_ID, name);
    }

    public ResourceLocation getId() {
        return this.id;
    }

    public boolean equals(ResourceLocation obj) {
        return this.id.equals(obj);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        return id.toString();
    }
}
