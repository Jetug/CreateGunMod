package com.nukateam.ntgl.common.datagen;

import com.nukateam.ntgl.Ntgl;
import com.nukateam.ntgl.common.foundation.init.NtglDamageTypes;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.TagsProvider;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageType;
import net.minecraftforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

/**
 * Author: MrCrayfish
 */
public class DamageTypeGen extends TagsProvider<DamageType> {
    public DamageTypeGen(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider, @Nullable ExistingFileHelper existingFileHelper) {
        super(output, Registries.DAMAGE_TYPE, lookupProvider, Ntgl.MOD_ID, existingFileHelper);
    }

//    @Override
//    protected void addTags(HolderLookup.Provider provider) {
//        this.tag(DamageTypeTags.IS_PROJECTILE).add(NtglDamageTypes.BULLET);
//    }

    @Override
    protected void addTags(HolderLookup.Provider provider) {
        ResourceKey<DamageType> bulletKey = ResourceKey.create(
                Registries.DAMAGE_TYPE,
                ResourceLocation.fromNamespaceAndPath(Ntgl.MOD_ID, "bullet")
        );

        this.tag(DamageTypeTags.IS_PROJECTILE)
                .add(bulletKey);

    }

    @Override
    public String getName() {
        return "Ntgl Damage Type Tags";
    }
}
