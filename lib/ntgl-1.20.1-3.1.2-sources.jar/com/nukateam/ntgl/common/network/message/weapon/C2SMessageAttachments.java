package com.nukateam.ntgl.common.network.message.weapon;

import net.minecraft.world.InteractionHand;
import net.minecraftforge.network.NetworkEvent;
import com.nukateam.ntgl.modules.network.IMessage;
import com.nukateam.ntgl.common.network.ServerPlayHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;

/**
 * Author: MrCrayfish
 */
public class C2SMessageAttachments implements IMessage<C2SMessageAttachments> {
    private InteractionHand hand = InteractionHand.MAIN_HAND;

    public C2SMessageAttachments() {}

    public C2SMessageAttachments(InteractionHand hand) {
        this.hand = hand;
    }

    @Override
    public void encode(C2SMessageAttachments message, FriendlyByteBuf buffer) {
        buffer.writeEnum(message.hand);
    }

    @Override
    public C2SMessageAttachments decode(FriendlyByteBuf buffer) {
        return new C2SMessageAttachments(buffer.readEnum(InteractionHand.class));
    }

    @Override
    public void handle(C2SMessageAttachments message, NetworkEvent.Context supplier) {
        supplier.enqueueWork((() -> {
            ServerPlayer player = supplier.getSender();
            if (player != null) {
                ServerPlayHandler.handleAttachments(player, message.hand);
            }
        }));
        supplier.setPacketHandled(true);
    }
}
